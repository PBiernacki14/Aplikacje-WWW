
list=[1,2,3,4,5,6,7,8,9,10]

list

for i,j in enumerate(list):
    if i >= 4:

