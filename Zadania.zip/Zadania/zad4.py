
zmienna_typu_string = "Ala ma kota"

print(dir(zmienna_typu_string))
help(zmienna_typu_string.isspace())