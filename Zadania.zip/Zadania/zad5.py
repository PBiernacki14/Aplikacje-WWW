
imie = "Paweł Biernacki"

imie2 = imie[::-1]
print(imie2.capitalize())